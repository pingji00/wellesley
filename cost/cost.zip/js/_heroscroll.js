$(function () {
  var hero = $('#hero');
  var down = $('#arrowHeroDown');

  down.onlick(hero.offset)
});
